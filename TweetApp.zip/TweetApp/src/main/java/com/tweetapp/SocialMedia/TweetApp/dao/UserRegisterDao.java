package com.tweetapp.SocialMedia.TweetApp.dao;


import java.io.IOException;

import com.tweetapp.SocialMedia.TweetApp.model.RegisterDto;

public interface UserRegisterDao  {
	
	
	public void userRegister(RegisterDto data)throws IOException;
	
	public void viewAllUser()throws IOException;

}
