package com.tweetapp.SocialMedia.TweetApp.Controller;

import java.io.IOException;
import java.util.Scanner;

import com.tweetapp.SocialMedia.TweetApp.Util.Validation;
import com.tweetapp.SocialMedia.TweetApp.dao.TweetDao;
import com.tweetapp.SocialMedia.TweetApp.dao.UserDao;
import com.tweetapp.SocialMedia.TweetApp.dao.UserRegisterDao;

import com.tweetapp.SocialMedia.TweetApp.daoImpl.RegisterDaoImpl;
import com.tweetapp.SocialMedia.TweetApp.daoImpl.TweetDaoImpl;
import com.tweetapp.SocialMedia.TweetApp.daoImpl.UserDaoImpl;
import com.tweetapp.SocialMedia.TweetApp.model.RegisterDto;
import com.tweetapp.SocialMedia.TweetApp.model.UserTweet;

public class TweetAppController {
	public static String firstName;
	public static String lastName;
	public static String gender;
	public static String dob;
	public static String email;
	public static String password;
	public static String tweet;
	public static String date;

	public void TwitterApp() throws IOException {
		UserRegisterDao registerservice = new RegisterDaoImpl();
		TweetDao tweetservice = new TweetDaoImpl();
		UserDao userservice = new UserDaoImpl();
		Scanner sc = new Scanner(System.in);
		int choice;
		System.out.println("Hi!" + "Choose your option from the below list ");
		System.out.println("Enter 1 for Registeration");
		System.out.println("Enter 2 to view the Tweet");
		System.out.println("Enter 3 to login and password Reset and postTweet");
		System.out.println("Enter 4 for viewAllUsers ");
		System.out.println("Enter 5 to forgetPasswod");
		System.out.println("Enter 6 logout ");

		choice = sc.nextInt();

		switch (choice) {
		case 1:
			sc.nextLine();
			System.out.println("Enter the first name");
			firstName = sc.nextLine();
			System.out.println("Enter the last name");
			lastName = sc.nextLine();
			System.out.println("Enter the gender(M/F)");
			gender = sc.nextLine();
			System.out.println("Enter the dob in (DD/MM/YYYY)");
			dob = sc.nextLine();
			System.out.println("Enter the email");
			email = sc.nextLine();
			System.out.println("Enter the password");
			System.out.println(
					"Password must be 8-20 charactes,atleast with one digits,one lowercase and one uppercase ");
			password = sc.nextLine();
			boolean validatedEmail = Validation.validEmail(email);
			boolean validatedPassword = Validation.validPassword(password);
			boolean validatedDob = Validation.validDob(dob);
			boolean validatedName = Validation.validName(firstName);

			RegisterDto data = new RegisterDto(firstName, lastName, gender, dob, email, password);

			if (validatedEmail && validatedPassword && validatedDob && validatedName) {
				// && validatedPassword && validatedDob && validatedName) {
				registerservice.userRegister(data);
			}

			break;

		case 2:
			sc.nextLine();

			int option;
			System.out.println("Enter 1 to viewTweet");
			System.out.println("Enter 2 to viewAlltweet");
			option = sc.nextInt();
			if (option == 1) {
				sc.nextLine();
				System.out.println("Enter the email");
				email = sc.nextLine();

				if (Validation.validEmail(email)) {

					tweetservice.viewTweet(email);
				}
			}
			// System.out.println("test");

			else if (option == 2) {
				tweetservice.viewAllTweet();
			} else {
				System.out.println("Enter the valid option");
			}

			break;
		case 3:
			sc.nextLine();
			System.out.println("Enter the email");
			email = sc.nextLine();
			System.out.println("Enter the password");
			password = sc.nextLine();
			boolean check = false;
			if (Validation.validEmail(email)) {
				check = userservice.login(email, password);

				if (check) {
					System.out.println("Do you want to reset password? please enter 1");
					System.out.println("Are you like to post the tweet,Please enter 2");
					int TweetOption = sc.nextInt();
					if (TweetOption == 1) {
						sc.nextLine();
						System.out.println("Enter your new password");
						String password1 = sc.nextLine();

						tweetservice.passwordReset(email, password1);

					} else if (TweetOption == 2) {
						sc.nextLine();
						System.out.println("Enter the tweet");
						tweet = sc.nextLine();

						UserTweet data1 = new UserTweet(email, tweet, date);

						tweetservice.postTweet(data1);

					} else {
						System.out.println("Please enter the valid option");

					}
				}

			}

			break;
		case 4:

			registerservice.viewAllUser();

			break;

		case 5:
			sc.nextLine();
			System.out.println("Enter the email");
			email = sc.nextLine();
			System.out.println("Enter the dob in (DD/MM/YYYY)");
			dob = sc.nextLine();
			System.out.println("Enter your new password");
			password = sc.nextLine();
			if (Validation.validEmail(email) && Validation.validPassword(password) && Validation.validDob(dob)) {
				if (userservice.forgetPassword(email, password, dob)) {
					System.out.println("Password Updated Sucessfully.Pleas login with Updated Password!");
				}

				else {
					System.out.println("Invalid details");
				}
			}

			break;

		case 6:
			sc.nextLine();
			System.out.println("Enter the email");
			email = sc.nextLine();
			userservice.logout(email);
			System.out.println("Logged out");
			break;
		}
	}

}
