package com.tweetapp.SocialMedia.TweetApp;

import java.io.IOException;

import com.tweetapp.SocialMedia.TweetApp.Controller.TweetAppController;

public class TweetApp {

	public static void main(String[] args) throws IOException {

		TweetAppController app = new TweetAppController();
		app.TwitterApp();
	}
}
