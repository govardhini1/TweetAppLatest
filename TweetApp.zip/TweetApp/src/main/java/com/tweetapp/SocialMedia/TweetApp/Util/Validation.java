package com.tweetapp.SocialMedia.TweetApp.Util;

import java.util.regex.Pattern;

public class Validation {

	public static boolean validPassword(String Password) {
		String passRegex = "^(?=.*[0-9])" + "(?=.*[a-z])(?=.*[A-Z])" + "(?=.*[@#$%^&+=])" + "(?=\\S+$).{8,20}$";
		Pattern pat = Pattern.compile(passRegex);
		if (Password == null) {
			return false;
		}
		return pat.matcher(Password).matches();

	}

	public static boolean validEmail(String email) {
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z"
				+ "A-Z]{2,7}$";

		Pattern pat = Pattern.compile(emailRegex);
		if (email == null && email.equalsIgnoreCase("")) {
			return false;
		}
		return pat.matcher(email).matches();

	}

	public static boolean validDob(String dob) {
		String dobRegex = "^[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}$";
		Pattern pat = Pattern.compile(dobRegex);
		if (dob == null) {
			return false;
		}
		return pat.matcher(dob).matches();
	}

	public static boolean validName(String firstName) {
		String nameRegex = "^[A-Za-z]\\w{5,29}$";
		Pattern pat = Pattern.compile(nameRegex);
		if (firstName == null) {
			return false;
		}
		return pat.matcher(firstName).matches();

	}

}
