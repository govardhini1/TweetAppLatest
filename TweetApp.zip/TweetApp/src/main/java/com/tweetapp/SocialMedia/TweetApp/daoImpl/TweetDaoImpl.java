package com.tweetapp.SocialMedia.TweetApp.daoImpl;

import java.io.IOException;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.tweetapp.SocialMedia.TweetApp.Util.ConnectionHandler;
import com.tweetapp.SocialMedia.TweetApp.dao.TweetDao;

import com.tweetapp.SocialMedia.TweetApp.model.UserTweet;

public class TweetDaoImpl implements TweetDao {
	public Connection con = null;
	public PreparedStatement ps = null;
	private final static String userTweetquery = "select * from User_tweet where email=?";
	private final static String AllTweetquery = "select * from User_Tweet";
	private final static String InsertTweetqery = "insert into user_tweet values(?,?,?)";
	private final static String updatePassquery = "update user set password=? where  email=?";

	public void viewTweet(String email) throws IOException {
		try {
			con = ConnectionHandler.getConnection();
			ps = con.prepareStatement(userTweetquery);
			ps.setString(1, email);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				System.out.println(rs.getString(1) + " posted:\n " + rs.getString(2) + " at " + rs.getString(3));
			}
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	public void viewAllTweet() throws IOException {
		try {
			con = ConnectionHandler.getConnection();

			ps = con.prepareStatement(AllTweetquery);
			ResultSet rs = ps.executeQuery();
			rs = ps.executeQuery();
			while (rs.next()) {
				System.out.println(rs.getString(1) + " posted:\n " + rs.getString(2) + " at " + rs.getString(3));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void postTweet(UserTweet data1) throws IOException {

		LocalDateTime date = LocalDateTime.now();
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
		String formatedDate = date.format(format);

		try {
			con = ConnectionHandler.getConnection();
			ps = con.prepareStatement(InsertTweetqery);
			ps.setString(1, data1.getEmail());
			ps.setString(2, data1.getTweet());
			ps.setString(3, formatedDate);
			ps.executeUpdate();
			System.out.println("posted Sucessfully!");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void passwordReset(String email, String password) throws IOException {
		try {
			con = ConnectionHandler.getConnection();
			ps = con.prepareStatement(updatePassquery);
			ps.setString(1, password);
			ps.setString(2, email);
			ps.executeUpdate();
			System.out.println("Sucessfully reset the password!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
