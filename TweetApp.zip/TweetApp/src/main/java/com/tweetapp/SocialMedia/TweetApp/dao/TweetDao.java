package com.tweetapp.SocialMedia.TweetApp.dao;

import java.io.IOException;

import com.tweetapp.SocialMedia.TweetApp.model.UserTweet;

public interface TweetDao {
	public void viewTweet(String email) throws IOException;

	public void viewAllTweet() throws IOException;

	public void postTweet(UserTweet data1) throws IOException;

	public void passwordReset(String email, String password) throws IOException;

}
